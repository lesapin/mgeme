<?php
  require __DIR__ . '/cgi/PHP-Source-Query/SourceQuery/bootstrap.php'; 
  use xPaw\SourceQuery\SourceQuery;

  define( 'SQ_SERVER_ADDR', 'mge.me' );
  define( 'SQ_SERVER_PORT', 27015 );
  define( 'SQ_TIMEOUT', 1 );
  define( 'SQ_ENGINE', SourceQuery::SOURCE );

  $Query = new SourceQuery();

  try {
    $Query->Connect( SQ_SERVER_ADDR, SQ_SERVER_PORT, SQ_TIMEOUT, SQ_ENGINE );
    $ServerInfo = $Query->GetInfo();

    $GLOBALS["IsOnline"]   = True;
    $GLOBALS["Players"]    = $ServerInfo["Players"];
    $GLOBALS["MaxPlayers"] = $ServerInfo["MaxPlayers"];

    if ($ServerInfo["Players"] > 0) {
      $PlayerInfo = $Query->GetPlayers();
      $PlayerNames;	    
      
      for ($i = 0; $i < $ServerInfo["Players"]; $i++) {
	$PlayerNames[$i] = $PlayerInfo[$i]["Name"];
      }

      $GLOBALS["Names"] = $PlayerNames;
    }
  }
  catch( Exception $e ) {
    $GLOBALS["IsOnline"]   = False;
    //echo $e->getMessage();
  }
  finally {
    $Query->Disconnect();
  }
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>MGE.ME :: Connect</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta charset="utf-8">
  <link rel="icon" type="image/png" href="https://ucarecdn.com/3b82283e-54d4-4736-9f61-3d3d47bc51d1/-/scale_crop/32x32/">
  <link rel="stylesheet" href="https://ucarecdn.com/b7819327-b07c-4261-a4d2-d0c0e5f92def/">
  <link rel="stylesheet" href="./static/styles.css">
</head>
<body>
  <div class="top-banner">
    <?php
      if ($GLOBALS["IsOnline"]) {
        echo "SERVER: <span class=\"server-status\">ONLINE</span> | ";
	echo "PLAYERS: <span class=\"server-status\">";
	echo $GLOBALS["Players"];
	echo "/";
	echo $GLOBALS["MaxPlayers"];
	echo "</span> >> ";

	if ($GLOBALS["Names"]) {
	  foreach ($GLOBALS["Names"] as $key => $value) {
            echo "<span class=\"player-name\">";
	    echo $value;
	    echo "</span>";
          }
        }
      } else {
        echo "SERVER: <span class=\"server-status\">OFFLINE</span>";
      }
    ?>
  </div>
  <div class="center">
    <img alt="mge logo" src="https://ucarecdn.com/b658552e-48a3-4c42-ac0e-771dc70147ba/">
    <h1>ENTER<code> 
      CONNECT MGE.ME </code>IN CONSOLE OR <a href="steam://connect/167.235.27.29:27015">CLICK HERE</a> TO PLAY
    </h1>
  </div>
  <div class="bottom-banner">
    (C)
    <?php
      echo date("Y");
    ?>
    MGE.ME
  </div>
</body>
</html>

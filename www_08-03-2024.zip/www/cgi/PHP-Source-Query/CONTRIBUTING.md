* **This library is intended for software developers**, if you do not know how write code in PHP, please do not create issues.
* Please do not create issues when you are unable to retrieve information from a server *(e.g. issues with UDP connectivity)*, unless you can prove that there is a bug within the library.
